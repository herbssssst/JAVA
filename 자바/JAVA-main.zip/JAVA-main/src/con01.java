
public class con01 {

	public static void main(String[] args) 
	{
		int i=0;
		/*for(i=1; i<=10; i++)
		{
		 	if(i==5) continue;
			System.out.println(i);
		}*/
		 
		while(i<=10)
		{
			i++;
			if(i==5) continue;
			System.out.print (i+" ");
		}

	}

}
