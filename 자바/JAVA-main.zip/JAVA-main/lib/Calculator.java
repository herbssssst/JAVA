package com.lib;

public abstract class Calculator {
	abstract public int add(int a, int b);
	abstract public int minus(int a, int b);
	abstract public double avg(int[] a);
}
